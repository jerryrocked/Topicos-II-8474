<?php
include 'templates/header.php';
require_once 'vendedor.php';
require_once "sesion.php";?>

<style>
<?php include 'style/style.css';?>
</style>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<html>
<body>

<?php
$rut_vendedores = array();

# Validamos si es que noe existe el array de vendedores, si no existe lo creamos
if (!isset($_SESSION["vendedores_array"])) {
  # Creamos un atributo de nuestra sesion como array
  $_SESSION["vendedores_array"] = array();
  echo "El largo es: ".sizeof($_SESSION["vendedores_array"]);
}

$vendedores = $_SESSION["vendedores_array"];

if(sizeof($_SESSION["vendedores_array"]) > 0){

  foreach($vendedores as $vendedor){
    $rut_vendedor = unserialize($vendedor)->get_rut();
    array_push($rut_vendedores, $rut_vendedor);
  }
}


if (in_array($_POST["rut"], $rut_vendedores)){
  #header("Location:error_vendedor.php");
  include 'error_vendedor.php';
}
else{
  # Creamos al nuevo vendedor con los parametros recibidos
  $vendedor = new Vendedor($_POST["rut"],$_POST["name"],$_POST["apellido"],0,0,0,0,0,0,0,0);

  # Insertamos al nuevo vendedor en el array de vendedores
  array_push($_SESSION["vendedores_array"], serialize($vendedor));
  # Imprimimos nuestro array de la sesion
  echo "<pre>";
  print_r($_SESSION["vendedores_array"]);
  echo "</pre>";
}




#$vendedor->setAttribute("nombre",$_POST["nombre"]);
#$vendedor->setAttribute("apellido",$_POST["apellido"]);
#$vendedor->setAttribute("rut",$_POST["rut"]);

#$vendedor->set_nombre("Nio");
#$vendedor->set_apellido("Garcia");
#$vendedor->set_rut("123");

//echo "Nombre: ".$vendedor->get_nombre();
// echo "<br>";
// echo "Apellido: ".$vendedor->get_apellido();
// echo "<br>";
// echo "Rut: ".$vendedor->get_rut();
// echo "<br>";


?>

<body>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" ></script>
</html>
