<?php
include 'templates/header.php';
require_once 'vendedor.php';
require_once "sesion.php";?>

<?php
header('Location:index.php');?>

<style>
<?php include 'style/style.css';?>
</style>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<html>
<body>

<?php
// Recibimos los datos de la venta e inicializamos las variables
$rut_vendedor = $_POST['rut'];
$juego = $_POST['juego'];
$cantidad = intval($_POST['cantidad_vendida']);
$vendedores = $_SESSION['vendedores_array'];
$new_array = array();

// Recorremos la lista de vendedores alojadas en la sesion
foreach ($vendedores as $vendedor){
    $el_vendedor = unserialize($vendedor);
    
    if ($rut_vendedor == unserialize($vendedor)->get_rut()){
         
        // Validamos si el juego a vender es COD
        if ($juego == "COD"){
            $cantidad_nueva = $el_vendedor->get_vtas_cod() + $cantidad; // Le sumamos la venta a al vendedor
            $el_vendedor->set_vtas_cod($cantidad_nueva); // Seteamos la cantidad
            
            $comision_cod = $el_vendedor->get_comision_cod();
            $el_vendedor->set_comision_cod(($comision_cod + ($cantidad*34500)) *0.06); // Seteamos la cantidad
            $el_vendedor->set_comision_total($el_vendedor->get_comision_total() + $el_vendedor->get_comision_cod()); // Seteamos la cantidad
            
            $_SESSION['vtas_cod'] = $_SESSION['vtas_cod'] + $cantidad; // Sumamos la venta a la cantidad vendida alojada en la sesion
            
            $vtas_totales = $el_vendedor->get_vtas_total();
            $el_vendedor->set_vtas_total($vtas_totales + $cantidad*34500); // Seteamos las ventas totales
        }
        // Validamos si el juego a vender es MINE
        if ($juego == "MIN"){
            $cantidad_nueva = $el_vendedor->get_vtas_mine() + $cantidad; // Le sumamos la venta a al vendedor
            $el_vendedor->set_vtas_mine($cantidad_nueva); // Seteamos la cantidad
            
            $comision_mine = $el_vendedor->get_comision_mine();
            $el_vendedor->set_comision_mine(($comision_mine + ($cantidad*8800)) *0.04); // Seteamos la cantidad
            $el_vendedor->set_comision_total($el_vendedor->get_comision_total() + $el_vendedor->get_comision_mine()); // Seteamos la cantidad
            
            $_SESSION['vtas_mine'] = $_SESSION['vtas_mine'] + $cantidad; // Sumamos la venta a la cantidad vendida alojada en la sesion
            
            $vtas_totales = $el_vendedor->get_vtas_total();
            $el_vendedor->set_vtas_total($vtas_totales + $cantidad*8800);
        }
        // Validamos si el juego a vender es FOR
        if ($juego == "FOR"){
            $cantidad_nueva = $el_vendedor->get_vtas_for() + $cantidad; // Le sumamos la venta a al vendedor
            $el_vendedor->set_vtas_for($cantidad_nueva); // Seteamos la cantidad
            
            $comision_for = $el_vendedor->get_comision_for();
            $el_vendedor->set_comision_for(($comision_for + ($cantidad*58200)) *0.09); // Seteamos la cantidad
            $el_vendedor->set_comision_total($el_vendedor->get_comision_total() + $el_vendedor->get_comision_for()); // Seteamos la cantidad
            
            $_SESSION['vtas_for'] = $_SESSION['vtas_for'] + $cantidad; // Sumamos la venta a la cantidad vendida alojada en la sesion
            
            $vtas_totales = $el_vendedor->get_vtas_total();
            $el_vendedor->set_vtas_total($vtas_totales + $cantidad*58200);
        }    
    }

    array_push($new_array, serialize($el_vendedor));
    
}
$_SESSION['vendedores_array'] = $new_array;
?>
<body>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" ></script>
</html>