<?php
require_once 'vendedor.php';
include 'sesion.php';

# Inicio sesion
#session_start();

$session = new Session();

# Asignamos las variables a la sesion
$_SESSION['usuario'] = $_POST['usuario'];
$_SESSION['password'] = $_POST['psw'];
$session->setAttribute("vtas_cod",0);
$session->setAttribute("vtas_mine",0);
$session->setAttribute("vtas_for",0);
#$_SESSION['vtas_cod'] = 0;
#$_SESSION['vtas_mine'] = 0;
#$_SESSION['vtas_for'] = 0;

if($_SESSION['usuario'] != Null){
    $_SESSION['vtas_cod'] = 0;
    $_SESSION['vtas_mine'] = 0;
    $_SESSION['vtas_for'] = 0;

    if($_SESSION['password'] != Null){header("Location:index.php");}
    
}else{
    echo "Error en la autenticacion";
}

?>