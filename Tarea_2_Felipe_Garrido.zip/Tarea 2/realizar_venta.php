<?php include 'templates/header.php';?>

<style>
<?php include 'style/style.css';?>
</style>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<!-- <button class="open-button" onclick="openForm()">Open Form</button> -->
<div class="container">
      <div class="form" id="myForm">
        <form action="r_vta.php" method="post" class="form-container">
          <h1>Realizar Venta</h1>

          <label for="rut"><b>Rut Vendedor</b></label>
          <input type="text" placeholder="12345678-1" class= "form-control" name="rut" required>

          <label for="juego"><b>Juego</b></label>
          <select name="juego" class="form-select form-control-lg" aria-label="Default select example">
            <option value="COD">COD</option>
            <option value="MIN">MIN</option>
            <option value="FOR">FOR</option>
          </select>

          <label for="cantidad_vendida"><b>Cantidad</b></label>
          <input type="number" min="1" max="99" class= "form-control form-control-lg" placeholder="1" name="cantidad_vendida" required>

          <button type="submit" class="btn">Realizar</button>
          </form>
      </div>
  </div>