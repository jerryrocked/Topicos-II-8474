<?php

class Session{
	function __construct(){
		if (!isset($_SESSION)){
			session_start();
		}
	}
	function setAttribute($attribute, $value){
		if (session_status() === PHP_SESSION_ACTIVE && is_string($attribute)){
			$_SESSION[$attribute]= $value;
		} 
	}
	function getAttribute($attribute){
		if (session_status() === PHP_SESSION_ACTIVE && is_string($attribute) && isset($_SESSION[$attribute])){
			return $_SESSION[$attribute];
		} 
		return null;

	}
	function deleteAttribute($attribute){
		if (session_status() === PHP_SESSION_ACTIVE && is_string($attribute) && isset($_SESSION[$attribute])){
			unset($_SESSION[$attribute]);
		} 		
	}
	function destroySession(){
		session_destroy();
	}	

}

class Fruit {
	public $name;
	public $color;
  
	function __construct($name, $color) {
		$this->name = $name;
	  	$this->color = $color;
	}

	function get_name(){
		return $this->name;
	} 

	function get_color(){
		return $this->color;
	} 
	function __destruct() {
	  echo "The fruit is {$this->name} and the color is {$this->color}.";
	}
}


  

//$session = new Session();
//$session->destroySession();

?>