<?php include 'templates/header.php';
      
# Inicio sesion
#session_start();?>

<style>
<?php include 'style/style.css';?>
</style>

<h2> 

<?php 
$session_user = $_SESSION['usuario'];

# Validamos que el usuario haya sido ingresado
if($_SESSION['usuario'] == null || $_SESSION['usuario'] == ""){
    
    echo "Usted no posee autorización";
    die();
}

echo "Bienvenido " .$session_user;

?> 

</h2>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<!-- TABLA -->
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <table class="table" id="tabla_vtas_juegos">
              <thead>
                <th>Imagen Juego</th>
                <th>Precio</th>
                <th>Comision</th>
                <th>Vendidos</th>
                <th>Vendidos $</th>
              </thead>
              <tbody>
                  <?php
                    #for($i = 0;){
                  ?>
                    <tr>
                        <td><img src="images/cod.webp" class="rounded float-start" width=150 height= 100></td>
                        <td><h2>$34.500</h2></td>
                        <td><h4>6%</h4></td>
                        <td><?php echo $_SESSION['vtas_cod']?></td>
                        <td><h4><?php echo '$'.number_format($_SESSION['vtas_cod']*34500, 0, ",", ".");?></h4></td>
                    </tr>  
                    <tr>
                        <td><img src="images/mine.jpeg" class="rounded float-start" width=150 height=100></td>
                        <td><h2>$8.800</h2></td>
                        <td><h4>4%</h4></td>
                        <td><?php echo $_SESSION['vtas_mine']?></td>
                        <td><h4><?php echo '$'.number_format($_SESSION['vtas_mine']*8800, 0, ",", ".");?></h4></td>
                    </tr>
                    <tr>
                        <td><img src="images/fortnite.jpg" class="rounded float-start" width=150 height=100></td>
                        <td><h2>$58.200</h2></td>
                        <td><h4>9%</h4></td>
                        <td><?php echo $_SESSION['vtas_for']?></td>
                        <td><h4><?php echo '$'.number_format($_SESSION['vtas_for']*58200, 0, ",", ".");?></h4></td>
                    </tr>                 
                  <?php
                  #}
                  ?> 
              </tbody>
            </table> 
        </div>
    </div>
</div>
 
</table>



