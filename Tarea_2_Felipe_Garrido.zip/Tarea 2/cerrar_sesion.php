<?php
# Reanudamos sesion
session_start();
# Destuimos la sesion
session_destroy();
header("Location:login.php");
error_reporting(0);
?>