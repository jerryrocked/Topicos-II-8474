<?php

class Vendedor {

    public $rut;
    public $nombre;
    public $apellido;
    public $vtas_cod;
    public $vtas_mine;
    public $vtas_for;
    public $vtas_total;
    public $comision_cod;
    public $comision_mine;
    public $comision_for;
    public $comision_total;
    
    
    function __construct($rut, $nombre, $apellido, $vtas_cod, $vtas_mine, $vtas_for, $vtas_total, $comision_cod, $comision_mine, $comision_for, $comision_total) {
        $this->rut = $rut;
        $this->nombre = $nombre;
        $this->apellido = $apellido;
        $this->vtas_cod = $vtas_cod;
        $this->vtas_mine = $vtas_mine;
        $this->vtas_for = $vtas_for;
        $this->vtas_total = $vtas_total;
        $this->comision_cod = $comision_cod;
        $this->comision_mine = $comision_mine;
        $this->comision_for = $comision_for;
        $this->comision_total = $comision_total;
    }

    // SET

    function set_rut($rut){
        $this->rut = $rut;
    }

    function set_nombre($nombre){
        $this->nombre = $nombre;
    }

    function set_apellido($apellido){
        $this->apellido = $apellido;
    }

    function set_vtas_cod($vtas_cod){
        $this->vtas_cod = $vtas_cod;
    }

    function set_vtas_mine($vtas_mine){
        $this->vtas_mine = $vtas_mine;
    }

    function set_vtas_for($vtas_for){
        $this->vtas_for = $vtas_for;
    }

    function set_vtas_total($vtas_total){
        $this->vtas_total = $vtas_total;
    }

    function set_comision_cod($comision_cod){
        $this->comision_cod = $comision_cod;
    }

    function set_comision_mine($comision_mine){
        $this->comision_mine = $comision_mine;
    }

    function set_comision_for($comision_for){
        $this->comision_for = $comision_for;
    }

    function set_comision_total($comision_total){
        $this->comision_total = $comision_total;
    }

    // GET

    function get_rut(){
        return $this->rut;
    }

    function get_nombre(){
        return $this->nombre;
    }

    function get_apellido(){
        return $this->apellido;
    }

    function get_vtas_cod(){
        return $this->vtas_cod;
    }

    function get_vtas_mine(){
        return $this->vtas_mine;
    }

    function get_vtas_for(){
        return $this->vtas_for;
    }

    function get_vtas_total(){
        return $this->vtas_total;
    }

    function get_comision_cod(){
        return $this->comision_cod;
    }

    function get_comision_mine(){
        return $this->comision_mine;
    }

    function get_comision_for(){
        return $this->comision_for;
    }

    function get_comision_total(){
        return $this->comision_total;
    }
}
?>