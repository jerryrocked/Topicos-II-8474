<?php
include 'templates/header.php';
require_once 'vendedor.php';
require_once "sesion.php";?>

<style>
<?php include 'style/style.css';?>
</style>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<html>
<body>

<h2> 

<?php 
$session_user = $_SESSION['usuario'];

# Validamos que el usuario haya sido ingresado
if($_SESSION['usuario'] == null || $_SESSION['usuario'] == ""){
    
    echo "Usted no posee autorización";
    die();
}

echo "Bienvenido " .$session_user;

?>

</h2>

<?php
$vendedores = $_SESSION['vendedores_array'];
?>


                    <?php
                    $cont = 0;
                    $rut_mayor_comision = "";
                    $mayor_comision = 0;

                    // Recorremos la lista de vendedores alojadas en la sesion
                    foreach ($vendedores as $vendedor){

                        if ($cont == 0){
                            $rut_mayor_comision = unserialize($vendedor)->get_rut();
                            $mayor_comision = unserialize($vendedor)->get_comision_total();
                            $cont = $cont + 1;
                        }
                        else{
                            if ($mayor_comision < unserialize($vendedor)->get_comision_total()){
                                $mayor_comision = unserialize($vendedor)->get_comision_total();
                                $rut_mayor_comision = unserialize($vendedor)->get_rut();
                            }
                        }

                  
                    }
                    ?>     

<!-- TABLA -->
<div class="container">
    <div class="row">
        <div class="table-responsive">
            <table class="table table-hover table-bordered">
              <thead class="table-success">
                <th>RUT</th>
                <th>Nombre Vendedor</th>
                <th>Apellido</th>
                <th>Cantidad Ventas COD</th>
                <th>Cantidad Ventas MIN</th>
                <th>Cantidad Ventas FOR</th>
                <th>Total Ventas</th>
                <th>Comision Call Of Dutty</th>
                <th>Comision Minecraft</th>
                <th>Comision Fortnite</th>
                <th>Comision Total</th>
              </thead>
              <tbody>
                  <?php
                    // Recorremos la lista de vendedores alojadas en la sesion
                    foreach ($vendedores as $vendedor){
                        
                  ?>
                    <tr>
                        <?php
                        if (unserialize($vendedor)->get_rut() == $rut_mayor_comision){?>
                            <td><h5><?php echo unserialize($vendedor)->get_rut()?></h5></td>
                            <td><h5><?php echo unserialize($vendedor)->get_nombre()?></h5></td>
                            <td><h5><?php echo unserialize($vendedor)->get_apellido()?></h5></td>
                            <td><h5><?php echo unserialize($vendedor)->get_vtas_cod()?></h5></td>
                            <td><h5><?php echo unserialize($vendedor)->get_vtas_mine()?></h5></td>
                            <td><h5><?php echo unserialize($vendedor)->get_vtas_for()?></h5></td>
                            <td><h5><?php echo '$'.number_format(unserialize($vendedor)->get_vtas_total(), 0, ",", ".");?></h5></td>
                            <td><h5><?php echo '$'.number_format(unserialize($vendedor)->get_comision_cod(), 0, ",", ".");?></h5></td>
                            <td><h5><?php echo '$'.number_format(unserialize($vendedor)->get_comision_mine(), 0, ",", ".");?></h5></td>
                            <td><h5><?php echo '$'.number_format(unserialize($vendedor)->get_comision_for(), 0, ",", ".");?></h5></td>
                            <td><h5><?php echo '$'.number_format(unserialize($vendedor)->get_comision_total(), 0, ",", ".");?></h5></td>
                        
                        <?php
                        }
                        else{?>
                            <td><?php echo unserialize($vendedor)->get_rut()?></td>
                        
                        
                            <td><?php echo unserialize($vendedor)->get_nombre()?></td>
                            <td><?php echo unserialize($vendedor)->get_apellido()?></td>
                            <td><?php echo unserialize($vendedor)->get_vtas_cod()?></td>
                            <td><?php echo unserialize($vendedor)->get_vtas_mine()?></td>
                            <td><?php echo unserialize($vendedor)->get_vtas_for()?></td>
                            <td><h6><?php echo '$'.number_format(unserialize($vendedor)->get_vtas_total(), 0, ",", ".");?></h6></td>
                            <td><h6><?php echo '$'.number_format(unserialize($vendedor)->get_comision_cod(), 0, ",", ".");?></h6></td>
                            <td><h6><?php echo '$'.number_format(unserialize($vendedor)->get_comision_mine(), 0, ",", ".");?></h6></td>
                            <td><h6><?php echo '$'.number_format(unserialize($vendedor)->get_comision_for(), 0, ",", ".");?></h6></td>
                            <td><h6><?php echo '$'.number_format(unserialize($vendedor)->get_comision_total(), 0, ",", ".");?></h6></td>
                        <?php
                        }
                        ?>
                    </tr>       
                  <?php
                  }
                  ?>     
              </tbody>
            </table> 
        </div>
    </div>
</div>
 
</table>

<body>
<!-- SCRIPTS BOOTSTRAP -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" ></script>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.7/dist/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>

</html>