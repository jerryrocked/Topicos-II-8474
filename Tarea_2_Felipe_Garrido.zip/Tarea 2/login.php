<style>
<?php include 'style/style.css';?>
</style>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>

<form action="validar.php" method="post" id="login">
  <label for="usuario">USUARIO:</label><br>
  <input type="text" id="usuario" name="usuario"><br>
  <label for="psw">PASSWORD:</label><br>
  <input type="password" id="psw" name="psw"><br><br>
  <input type="submit" value="Submit">
</form>



<?php 
#session_destroy();
?>





</body>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" ></script>