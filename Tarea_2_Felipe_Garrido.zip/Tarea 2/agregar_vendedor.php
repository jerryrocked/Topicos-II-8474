<?php include 'templates/header.php';
      require_once 'vendedor.php';
      require_once "sesion.php";
?>

<style>
<?php include 'style/style.css';?>
</style>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>


  <h2>Agregar Un Vendedor Nuevo</h2>

  <!-- <button class="open-button" onclick="openForm()">Open Form</button> -->
  <div class="container">
      <div class="form" id="myForm">
        <form action="a_vn.php" method="post" class="form-container">
          <h1>Registrate</h1>

          <label for="nombre"><b>Nombre</b></label>
          <input type="text" pattern="^[A-Za-z]+" placeholder="Felipe" name="name" required>

          <label for="Apellido"><b>Apellido</b></label>
          <input type="text" pattern="^[A-Za-z]+" placeholder="Garrido" name="apellido" required>

          <label for="rut"><b>Rut</b></label>
          <input type="text" placeholder="12345678-9" min="10" max= "10" name="rut" required>

          <button type="submit" class="btn">Agregar</button>
          </form>
      </div>
  </div>


</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" ></script>