<?php 
# Inicio sesion
session_start();
?>

<style>
<?php include 'style/style.css';?>
</style>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Navbar</title>
</head>
<body>



<nav class="navbar navbar-expand-lg bg-light">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">APP</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php">Inicio</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="agregar_vendedor.php">Agregar Vendedor</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="realizar_venta.php">Vender Un Juego</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="lista_vendedores.php">Lista De Vendedores</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="mejor_vendedor.php">Mejor Vendedor</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="mejor_comision.php">Mejor Comision</a>
        </li>
        
      </ul>
    </div>
    <a href="cerrar_sesion.php">
    <button type="button" class="btn btn-danger">Cerrar Sesion</button>
    </a>
  </div>
</nav>
    
</body>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" ></script>