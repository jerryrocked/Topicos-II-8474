<?php
    @session_start();
    $nombre = '';
    $cantcod = '';
    $cantmin = '';
    $cantfor = '';
    $preciocod = 34500;
    $preciomin = 8800;
    $preciofor = 58200;
    $comcod = 0.06;
    $commin = 0.04;
    $comfor = 0.09;
    $error = '';
    if(!isset($_SESSION['info'])){
        $_SESSION['info'] = array();
    }
    if(isset($_POST['guardar'])){
        if(isset($_POST['nombre']) && trim($_POST['nombre']) != ''){
            if(!preg_match("/^[A-Za-z ]+$/", $_POST['nombre'])){
                $error.="El nombre sólo debe contener letras y espacios.<br>";
            }
            $nombre = $_POST['nombre'];
        } else {
            $error.= 'El nombre es obligatorio.<br>';
        }
        if(isset($_POST['cantcod']) && trim($_POST['cantcod']) != ''){
            if(!preg_match("/^[0-9]+$/", $_POST['cantcod']) || $_POST['cantcod'] < 0){
                $error.="La cantidad debe ser mayor que cero y no decimal.<br>";
            }
            $cantcod = $_POST['cantcod'];
        } else {
            $error.= 'La cantidad ventas COD es obligatoria.<br>';
        }
        if(isset($_POST['cantmin']) && trim($_POST['cantmin']) != ''){
            if(!preg_match("/^[0-9]+$/", $_POST['cantmin']) || $_POST['cantmin'] < 0){
                $error.="La cantidad debe ser mayor que cero y no decimal.<br>";
            }
            $cantmin = $_POST['cantmin'];
        } else {
            $error.= 'La cantidad ventas MIN es obligatoria.<br>';
        }
        if(isset($_POST['cantfor']) && trim($_POST['cantfor']) != ''){
            if(!preg_match("/^[0-9]+$/", $_POST['cantfor']) || $_POST['cantfor'] < 0){
                $error.="La cantidad debe ser mayor que cero y no decimal.<br>";
            }
            $cantfor = $_POST['cantfor'];
        } else {
            $error.= 'La cantidad ventas FOR es obligatoria.<br>';
        }

        if($error == ''){
            $ingresar = true;
            for($x = 0; $x < count($_SESSION['info']); $x++){
                if($_POST['nombre'] == $_SESSION['info'][$x]['nombre']){
                    $_SESSION['info'][$x]['cantcod'] = $_SESSION['info'][$x]['cantcod']+$cantcod;
                    $_SESSION['info'][$x]['cantmin'] = $_SESSION['info'][$x]['cantmin']+$cantmin;
                    $_SESSION['info'][$x]['cantfor'] = $_SESSION['info'][$x]['cantfor']+$cantcod;
                    $_SESSION['info'][$x]['comcod'] = $_SESSION['info'][$x]['cantfor']*$preciocod*$comcod;
                    $_SESSION['info'][$x]['commin'] = $_SESSION['info'][$x]['cantfor']*$preciomin*$commin;
                    $_SESSION['info'][$x]['comfor'] = $_SESSION['info'][$x]['cantfor']*$preciofor*$comfor;
                    $ingresar = false;
                    break;
                }
            }
            if($ingresar == true){
                array_push($_SESSION['info'], 
                    array('nombre' => $nombre, 'cantcod' => $cantcod, 'cantmin' => $cantmin, 'cantfor' => $cantfor, 'comcod' => $cantcod*$preciocod*$comcod, 'commin' => $cantmin*$preciomin*$commin, 'comfor' => $cantfor*$preciofor*$comfor));
            }
            $nombre = '';
            $cantcod = '';
            $cantmin = '';
            $cantfor = '';
        }
    } else if(isset($_POST['eliminar'])){
        foreach($_POST as $key => $valor){
            if(strpos($key, 'chk') !== false){
                $aux = $key;
                $nombreelim = substr($aux, 3);
                $nombreelim =str_replace('_',' ',$nombreelim);
                for($x = 0; $x < count($_SESSION['info']); $x++){
                    if($_SESSION['info'][$x]['nombre'] == $nombreelim){
                        unset($_SESSION['info'][$x]);
                        break;
                    }
                }
                $_SESSION['info'] = array_values($_SESSION['info']);
            }
        }
    }
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title></title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="css/estilo.css">
    </head>
    <body>
        <table class="formulario">
            <form method="POST">
                <tr>
                    <td class="tdform">Nombre</td>
                    <td class="tdform">Cantidad ventas COD</td>
                    <td class="tdform">Cantidad ventas MIN</td>
                    <td class="tdform">Cantidad ventas FOR</td>
                </tr>
                <tr>
                    <td><input class="inputform" type="input" id="nombre" name="nombre" value="<?=$nombre?>"></td>
                    <td><input class="inputform" type="input" id="cantcod" name="cantcod" value="<?=$cantcod?>"></td>
                    <td><input class="inputform" type="input" id="cantmin" name="cantmin" value="<?=$cantmin?>"></td>
                    <td><input class="inputform" type="input" id="cantfor" name="cantfor" value="<?=$cantfor?>"></td>
                </tr>
                <tr>
                    <td colspan="4"><button id="guardar" name="guardar" value="Guardar">Guardar</button></td>
                </tr>
            </form>
            <tr>
                <td colspan="4"><span id="error"><?=$error?></span></td>
            </tr>
        </table>
        <div style="overflow-x:auto">
            <table border=1>
                <tr>
                    <th>-</th>
                    <th>Nombre Vendedor</th>
                    <th>Cantidad ventas COD</th>
                    <th>Cantidad ventas MIN</th>
                    <th>Cantidad ventas FOR</th>
                    <th>Total ventas</th>
                    <th>Comisión COD</th>
                    <th>Comisión MIN</th>
                    <th>Comisión FOR</th>
                    <th>Comisión Total</th>
                </tr>
                <form method="POST">
                <?php
                if(count($_SESSION['info']) == 0){
                    echo "<tr><td colspan='10'>No existen registros</td></tr>";
                }else {
                    foreach($_SESSION['info'] as $info){
                        echo "<tr><td><input type='checkbox' id='chk".$info['nombre']."' name='chk".$info['nombre']."'></td>";
                        echo "<td>".$info['nombre']."</td>";
                        echo "<td>".$info['cantcod']."</td>";
                        echo "<td>".$info['cantmin']."</td>";
                        echo "<td>".$info['cantfor']."</td>";
                        echo "<td>".($info['cantcod']+$info['cantmin']+$info['cantfor'])."</td>";
                        echo "<td>".$info['comcod']."</td>";
                        echo "<td>".$info['commin']."</td>";
                        echo "<td>".$info['comfor']."</td>";
                        echo "<td>".($info['comcod']+$info['commin']+$info['comfor'])."</td></tr>";
                    }
                }
                ?>
                </table>
            </div>
            <table>
                <tr>
                    <td colspan="2"><button id="eliminar" name="eliminar" value="eliminar">Eliminar</button></td>
                    <td colspan="8"></td>
                </tr>
            </table>
        </form>
    </body>
</html>