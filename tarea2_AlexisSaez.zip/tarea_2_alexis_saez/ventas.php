<?php
    require_once "vendedor.php";    
    require_once "session.php";

    $session = new Session();

    // Obtenemos los datos del formulario
    $nombreVendedor = $_REQUEST["nombre"];
    $ventasCOD = $_REQUEST["v_cod"];
    $ventasMIN = $_REQUEST["v_min"];
    $ventasFOR = $_REQUEST["v_for"];

    // Instanciamos el objeto vendedor
    $vendedor = new Vendedor(
        $nombreVendedor,
        $ventasCOD,
        $ventasMIN,
        $ventasFOR
    );

    if (!count($vendedor->getErrors()['errors'])) {
        $vendedores = $session->getAttribute("vendedores");
        $vendedores[] = get_object_vars($vendedor);
        $session->setAttribute("vendedores", $vendedores); 
    }

    $session->setAttribute("errors", $vendedor->getErrors());

    header('Location: /?page=venta_view');

?>