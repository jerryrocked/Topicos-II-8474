<?php
// clase para manejar los vendedores
class Vendedor {
    private $errors;
    public $nombre;
    public $COD;
    public $MIN;
    public $FOR;

    public function __construct(
        $nombreVendedor,
        $ventasCOD,
        $ventasMIN,
        $ventasFOR
    ) {
        $this->errors = [
            "errors" => [],
            "nombre" => $nombreVendedor,
            "COD" => $ventasCOD,
            "MIN" => $ventasMIN,
            "FOR" => $ventasFOR,
        ];
        $this->setNombre($nombreVendedor);
        $this->setCOD($ventasCOD);
        $this->setMIN($ventasMIN);
        $this->setFOR($ventasFOR);
    }

    public function setNombre($nombreVendedor) {
        if (preg_match('/[^\w!@£\s]/', $nombreVendedor)) {
            $this->errors["errors"][] = "El nombre no puede contener caracteres especiales";
        }
        else {
            $this->nombre = $nombreVendedor;
        }
    }

    public function setCOD($ventasCOD) {
        if (is_numeric($ventasCOD) && $ventasCOD >= 0) {
            $this->COD = $ventasCOD;
        }
        else {
            $this->errors["errors"][] = "El COD debe ser un número positivo";
        }
    }

    public function setMIN($ventasMIN) {
        if (is_numeric($ventasMIN) && $ventasMIN >= 0) {
            $this->MIN = $ventasMIN;
        }
        else {
            $this->errors["errors"][] = "El MIN debe ser un número positivo";
        }
    }

    public function setFOR($ventasFOR) {
        if (is_numeric($ventasFOR) && $ventasFOR >= 0) {
            $this->FOR = $ventasFOR;
        }
        else {
            $this->errors["errors"][] = "El FOR debe ser un número positivo";
        }
    }

    public function getErrors() {
        return  count($this->errors['errors']) ? $this->errors : [
            "errors" => [],
            "nombre" => NULL,
            "COD" => NULL,
            "MIN" => NULL,
            "FOR" => NULL
        ];
    }

    public function getNombre() {
        return $this->nombre;
    }

    public function getCOD() {
        return $this->COD * 34500;
    }

    public function getMIN() {
        return $this->MIN * 8800;
    }

    public function getFOR() {
        return $this->FOR * 58200;
    }

    public function getVentas() {
        return $this->getCOD() + $this->getMIN() + $this->getFOR();
    }

    public function getComisionCOD() {
        return $this->getCOD() * 0.06;
    }

    public function getComisionMIN() {
        return $this->getMIN() * 0.04;
    }

    public function getComisionFOR() {
        return $this->getFOR() * 0.09;
    }

    public function getComisionTotal() {
        return $this->getComisionCOD() + $this->getComisionMIN() + $this->getComisionFOR();
    }
}
?>