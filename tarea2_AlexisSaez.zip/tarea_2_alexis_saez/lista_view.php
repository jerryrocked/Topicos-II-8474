<?php
    require_once "session.php";
    require_once "vendedor.php";

    $session = new Session();
    $vendedores = [];
    $totalCOD = 0;
    $totalMIN = 0;
    $totalMIN = 0;
    $vendedorMayor;

    // creamos la lista de vendedores
    foreach ($session->getAttribute("vendedores", []) as $vendedor_session) {
        $vendedor = new Vendedor(
            $vendedor_session["nombre"],
            $vendedor_session["COD"],
            $vendedor_session["MIN"],
            $vendedor_session["FOR"]
        );
        $vendedores[] = $vendedor;

        // Proceso donde obetenmos el vendedor con mayor comision 
        if (!$vendedorMayor) {
            $vendedorMayor = $vendedor;
        }
        else {
            if ($vendedor->getVentas() > $vendedorMayor->getVentas()) {
                $vendedorMayor = $vendedor;
            }
        }
    }

    function pesos($num) {
        return '$'.number_format($num, 0, ",", ".");
    }

?>

<h1>Listado de Vendedores</h1>

<?php if (!count($vendedores)):?>
    <p>No hay vendedores</p>
<?php else: ?>
    <?php foreach ($vendedores as $vendedor): ?>
        <article>
            <?php if ($vendedor === $vendedorMayor): ?>
                <h2 style='color:blueviolet;'><?php echo $vendedor->getNombre(); ?></h2>
            <?php else: ?>
                <h3><?php echo $vendedor->getNombre() ?></h3>
            <?php endif; ?>
            <table>
                <tr>
                    <td>Total Ventas</td>
                    <td>: <?php echo pesos($vendedor->getVentas()) ?></td>
                </tr>
                <tr>
                    <td>Total Comisión</td>
                    <td>: <?php echo pesos($vendedor->getComisionTotal()) ?></td>
                </tr>
            </table>
            <table>
                <tr>
                    <td></td>
                    <td><img src="media/cod.jpg" alt="COD" width="105" height="120"></td>
                    <td><img src="media/min.png" alt="MIN" width="105" height="120"></td>
                    <td><img src="media/for.jpg" alt="COD" width="105" height="120"></td>
                </tr>
                <tr>
                    <td>Precio de venta</td>
                    <td>$34.500</td>
                    <td>$8.800</td>
                    <td>$58.200</td>
                </tr>
                <tr>
                    <td>Total Ventas</td>
                    <td><?php echo pesos($vendedor->getCOD()) ?></td>
                    <td><?php echo pesos($vendedor->getMIN()) ?></td>
                    <td><?php echo pesos($vendedor->getFOR()) ?></td>
                </tr>
                <tr>
                    <td>Comisión</td>
                    <td><?php echo pesos($vendedor->getComisionCOD()) ?></td>
                    <td><?php echo pesos($vendedor->getComisionMIN()) ?></td>
                    <td><?php echo pesos($vendedor->getComisionFOR()) ?></td>
                </tr>
            </table>
        </article>
    <?php endforeach; ?>
<?php endif; ?>