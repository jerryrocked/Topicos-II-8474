<?php
    require_once "session.php";
    require_once "vendedor.php";

    $session = new Session();
    $vendedores = [];
    $totalCOD = 0;
    $totalMIN = 0;
    $totalMIN = 0;
    $vendedorMayor;

    // creamos la lista de vendedores
    foreach ($session->getAttribute("vendedores", []) as $vendedor_session) {
        $vendedor = new Vendedor(
            $vendedor_session["nombre"],
            $vendedor_session["COD"],
            $vendedor_session["MIN"],
            $vendedor_session["FOR"]
        );
        $vendedores[] = $vendedor;

        // Proceso donde obetenmos el vendedor con mayor comision 
        if (!$vendedorMayor) {
            $vendedorMayor = $vendedor;
        }
        else {
            if ($vendedor->getVentas() > $vendedorMayor->getVentas()) {
                $vendedorMayor = $vendedor;
            }
        }
    }

    function pesos($num) {
        return '$'.number_format($num, 0, ",", ".");
    }

?>

<h1>Vendedor con más comisión</h1>

<!-- Sección que genera el contenido -->

<?php if (!count($vendedores)):?>
    <p>No hay vendedores</p>
<?php else: ?>
    <article>
        <h2 style='color:blueviolet;'><?php echo $vendedorMayor->getNombre(); ?></h2>
        <table>
            <tr>
                <td>Total Ventas</td>
                <td>: <?php echo pesos($vendedorMayor->getVentas()) ?></td>
            </tr>
            <tr>
                <td>Total Comisión</td>
                <td>: <?php echo pesos($vendedorMayor->getComisionTotal()) ?></td>
            </tr>
        </table>
        <table>
            <tr>
                <td></td>
                <td><img src="media/cod.jpg" alt="COD" width="105" height="120"></td>
                <td><img src="media/min.png" alt="MIN" width="105" height="120"></td>
                <td><img src="media/for.jpg" alt="COD" width="105" height="120"></td>
            </tr>
            <tr>
                <td>Precio de venta</td>
                <td>$34.500</td>
                <td>$8.800</td>
                <td>$58.200</td>
            </tr>
            <tr>
                <td>Total Ventas</td>
                <td><?php echo pesos($vendedorMayor->getCOD()) ?></td>
                <td><?php echo pesos($vendedorMayor->getMIN()) ?></td>
                <td><?php echo pesos($vendedorMayor->getFOR()) ?></td>
            </tr>
            <tr>
                <td>Comisión</td>
                <td><?php echo pesos($vendedorMayor->getComisionCOD()) ?></td>
                <td><?php echo pesos($vendedorMayor->getComisionMIN()) ?></td>
                <td><?php echo pesos($vendedorMayor->getComisionFOR()) ?></td>
            </tr>
        </table>
    </article>
<?php endif; ?>