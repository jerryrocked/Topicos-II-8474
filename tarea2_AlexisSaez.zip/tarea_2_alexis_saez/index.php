<?php
    require_once "session.php";
    $session = new Session(); // inicio de sesion
    $page = $_GET['page']; // parámetro de la página
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Registro de Ventas</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>

        <!-- navbar con botones de fucionalidad -->
        <header>
            <article class="container">
                <p class="logo">RegistroVentas</p>
                <nav>
                    <form method="POST">
                        <?php
                            // configura los botones de funcionalidad
                            $paginas = [
                                'lista_view' => 'Lista Vendedores',
                                'venta_view' => 'Insertar Ventas',
                                'comision_view' => 'Mayor Comisión'
                            ];
                            foreach($paginas as $key => $value) {
                                $active = $page == $key ? "class='active'" : "";
                                echo "<button $active formaction='?page=$key'>$value</button>";
                            }
                        ?>
                    </form>
                </nav>
            </article>
        </header>

        <!-- Ruteador -->
        <section>
            <article class="container">
                <?php 
                    require(
                        in_array($page,  array_keys($paginas))
                        ? $page.".php" 
                        : "lista_view.php"
                    );
                ?>
            </article>
        </section>
        
        <!-- script javascript que limpia la barra de direcciones -->
        <script>
            window.history.pushState({}, document.title, "/");
        </script>
    </body>
</html>
