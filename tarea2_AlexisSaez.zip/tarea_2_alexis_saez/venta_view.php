<h1>Insertar Venta</h1>

<?php 
    $errors = $session->getAttribute("errors");
?>

<?php if ($errors["errors"] && count($errors["errors"])): ?> 
    <article class="container errors">
        <?php foreach ($errors["errors"] as $error): ?>
            <p><?php echo $error; ?></p>
        <?php endforeach; ?>
    </article>
<?php endif; ?>

<form method="POST" action="/ventas.php">
    <table>
        <tr>
            <td>Nombre Vendedor</td>
            <td>: <input type="text" name="nombre" value="<?php echo $errors["nombre"]; ?>"></td>
        </tr>
        <tr>
            <td>Copias COD vendidas</td>
            <td>: <input type="text" name="v_cod" value="<?php echo $errors["COD"] ?>"></td>
        </tr>
        <tr>
            <td>Copias MIN vendidas</td>
            <td>: <input type="text" name="v_min" value="<?php echo $errors["MIN"] ?>"></td>
        </tr>
        <tr>
            <td>Copias FOR vendidas</td>
            <td>: <input type="text" name="v_for" value="<?php echo $errors["FOR"] ?>"></td>
        </tr>
    </table>
    <br>
    <input type="submit" value="Guardar">
</form>
