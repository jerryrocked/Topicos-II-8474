<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vendedores</title>
    <link rel = "styleSheet" href = "css/styles.css">
</head>
<body class="body">
    <header class="header no-margin">
        <div class="contenedor">
            <div class="barra">
                <a class="logo" href="index.html">
                    <h1 class="logo__nombre centrar-texto no-margin">Tienda<span class = "logo__bold">Gamer</span></h1>
                </a>
            
                <nav class="navegacion">
                    <a href="#" class="navegacion__enlace"><img src="img/twiiter.png" width=32 height=32 alt="Síguenos en Twitter" /></a>
                    <a href="#" class="navegacion__enlace"><img src="img/instagram.png" width=32 height=32 alt="Síguenos en Instragram" /></a>
                    <a href="#" class="navegacion__enlace"><img src="img/facebook.png" width=32 height=32 alt="Síguenos en Facebook" /></a>
                    <a href="#" class="navegacion__enlace"><img src="img//wtsp.png" width=32 height=32 alt="Síguenos en watsp" /></a>
                </nav>
            </div>
        </div>


        <div class="header__texto">
            <h2 class="no-margin">Tienda de videojuegos</h2>
            <p class="no-margin">Compra los mejores juegos en 1 solo lugar</p>
        </div>
    </header>

    <div class="contenedor contenido-principal">
        <main class="blog">
            <h3>Juegos</h3>

            <article class="entrada">
                <div class="entrada__imagen">
                    <picture>
                        <img src="img/CoD.jpg" alt="imagen blog">
                    </picture>                    
                </div>
                
                <div class="entrada__contenido">
                    <h4 class="no-margin">Call of Duty</h4>
                    <p>Call of Duty es una serie de videojuegos de disparos en primera persona, de estilo bélico, desarrollada principal e inicialmente por Infinity Ward, Treyarch, Sledgehammer Games y en menor proporción Raven Software y distribuida por Activision.</p>
                    <p href="entrada.html" class="boton boton--primario c_blanco">$34500</p>
                </div>
            </article>

            <article class="entrada">
                <div class="entrada__imagen">
                    <picture>
                        <img src="img/Minecraft.jpg" alt="imagen blog">
                    </picture> 
                </div>
                
                <div class="entrada__contenido">
                    <h4 class="no-margin">Minecraft</h4>
                    <p>Minecraft es un videojuego de construcción de tipo «mundo abierto» o sandbox creado originalmente por el sueco Markus Persson, ​ y posteriormente desarrollado por Mojang Studios.​</p>
                    <p class="boton boton--primario c_blanco">$8800</p>
                </div>
            </article>

            <article class="entrada">
                <div class="entrada__imagen">
                    <picture>
                        <img src="img/Fornite.jpeg" alt="imagen blog">
                    </picture> 
                </div>
                
                <div class="entrada__contenido">
                    <h4 class="no-margin">Fornite</h4>
                    <p>Fortnite es un videojuego del año 2017 desarrollado por la empresa Epic Games, lanzado como diferentes paquetes de software que presentan diferentes modos de juego, pero que comparten el mismo motor de juego y mecánicas. Fue anunciado en los Spike Video Game Awards en 2011.</p>
                    <p class="boton boton--primario c_blanco">$58200</p>
                </div>
            </article>

        </main>  
        <aside class="sidebar">
            <h3>Página vendedores</h3>


            <a href="ventas.php" class="boton boton--secundario c_blanco">Ir</a>


        </aside>
    </div>

    <footer class="footer">
        <div class="contenedor">
            <div class="barra">
                <a class="logo" href="index.html">
                    <h1 class="logo__nombre centrar-texto no-margin">Tienda<span class = "logo__bold">Gamer</span></h1>
                </a>
            
                <nav class="navegacion">
                    <a href="#" class="navegacion__enlace"><img src="img/twiiter.png" width=32 height=32 alt="Síguenos en Twitter" /></a>
                    <a href="#" class="navegacion__enlace"><img src="img/instagram.png" width=32 height=32 alt="Síguenos en Instragram" /></a>
                    <a href="#" class="navegacion__enlace"><img src="img/facebook.png" width=32 height=32 alt="Síguenos en Facebook" /></a>
                    <a href="#" class="navegacion__enlace"><img src="img//wtsp.png" width=32 height=32 alt="Síguenos en watsp" /></a>
                </nav>
            
               
                   
            </div>
        </div>
    </footer>

</body>
</html>