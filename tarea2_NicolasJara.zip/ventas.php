<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vendedores</title>
    <link rel = "styleSheet" href = "css/styles.css">
</head>
<body class="body">
    <header class="header no-margin">
        <div class="contenedor">
            <div class="barra">
                <a class="logo" href="index.html">
                    <h1 class="logo__nombre centrar-texto no-margin">Tienda<span class = "logo__bold">Gamer</span></h1>
                </a>
            
                <nav class="navegacion">
                    <a href="#" class="navegacion__enlace"><img src="img/twiiter.png" width=32 height=32 alt="Síguenos en Twitter" /></a>
                    <a href="#" class="navegacion__enlace"><img src="img/instagram.png" width=32 height=32 alt="Síguenos en Instragram" /></a>
                    <a href="#" class="navegacion__enlace"><img src="img/facebook.png" width=32 height=32 alt="Síguenos en Facebook" /></a>
                    <a href="#" class="navegacion__enlace"><img src="img//wtsp.png" width=32 height=32 alt="Síguenos en watsp" /></a>
                </nav>
            </div>
        </div>


        <div class="header__texto">
            <h2 class="no-margin">Tienda de videojuegos</h2>
            <p class="no-margin">Compra los mejores juegos en 1 solo lugar</p>
        </div>
    </header>

    <div class="contenedor">
        
        <?php 
        session_start();  
            if (!isset($_SESSION['iniciar'])){
                $_SESSION['iniciar'] = 0;
            }
        ?>
        
        <main class="blog">
        <h2 class="titulo_2">Agregar vendedor y ventas</h2>
        
            <form action="sesion.php" method="POST" class="contenedor formulario">
            
                <div class="ventas_main">
                
                    <div>
                       
                        <h2 class="titulo_2">Nombre y apellido</h2>
                        <?php 
                            if ($_SESSION['iniciar']>0){
                                if (strlen($_SESSION['error1'])>0){
                                    echo "<p class='error'>".$_SESSION['error1']."</p>";  
                                }
                            }

                        ?>
                        <div class="campo">
                            <label class="campo__label" for="email">Nombre</label>
                            <input type="text" class="campo_texto" id="nom" name="nom" value="" >
                        </div>

                        <div class="campo">
                            <label class="campo__label" for="">Apellido</label>
                            <input type="text" class="campo_texto" id="ape" name="ape" value="" >
                        </div>
                    </div>
                    
                    <div>
                        <h2 class="titulo_2">Ventas</h2>
                        <div class="vendedor_ventas">
                            <div class="campo_imgventas">
                                <label class="" for=""><img class="img_ventas" src="img/CoD.jpg" alt="imagen blog"><br>Ventas COD</label>
                                <input type="number" class="campo_numerico" id="cod" name="cod" value="" >
                                <?php
                                    if ($_SESSION['iniciar']>0){
                                        if (strlen($_SESSION['error2'])>0){
                                            echo "<p class='error'>".$_SESSION['error2']."</p>";  
                                        }
                                    }
                                ?>
                            </div>

                            <div class="campo_imgventas">
                                <label class="" for=""><img class="img_ventas" src="img/Minecraft.jpg" alt="imagen blog"><br>Ventas Minecraft</label>
                                <input type="number" class="campo_numerico" id="mnc" name="mnc" value="" >
                                <?php
                                    if ($_SESSION['iniciar']>0){
                                        if (strlen($_SESSION['error3'])>0){
                                            echo "<p class='error'>".$_SESSION['error3']."</p>";  
                                        }
                                    }
                                ?>
                            </div>

                            <div class="campo_imgventas">
                                <label class="" for=""><img class="img_ventas" src="img/Fornite.jpeg" alt="imagen blog"><br>Ventas Fornite</label>
                                <input type="number" class="campo_numerico" id="fnt" name="fnt" value="" >
                                <?php
                                    if ($_SESSION['iniciar']>0){
                                        if (strlen($_SESSION['error4'])>0){
                                            echo "<p class='error'>".$_SESSION['error4']."</p>";  
                                        }
                                    }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="campo">
                    <input type="submit" value="Agregar" class="top_gap2 c_blanco boton boton--secundario">
                </div>
            </form>

            <div class="">
                <table class="table">
                    <tr class="table-bg">
                        <th style=" text-align: center;"> Nombre Vendedor </th>
                        <th style=" text-align: center;"> Cantida Ventas COD </th>
                        <th style=" text-align: center;"> Cantidad Ventas MIN </th>
                        <th style=" text-align: center;"> Cantidad Ventas FOR </th>
                        <th style=" text-align: center;"> Total Ventas </th>
                        <th style=" text-align: center;"> Comision Call of Duty </th>
                        <th style=" text-align: center;"> Comision Minecraft </th>
                        <th style=" text-align: center;"> Comision Fortnite </th>
                        <th style=" text-align: center;"> Comision Total </th>

                    </tr>    
                    <?php 
                        if ($_SESSION['iniciar']>0){
                            foreach($_SESSION['vendedor'] as &$vendedor){
                                echo "<tr>";
                                    echo  "<td>".$vendedor[0]."</td>";
                                    echo  "<td>".$vendedor[1]."</td>";
                                    echo  "<td>".$vendedor[2]."</td>";
                                    echo  "<td>".$vendedor[3]."</td>";
                                    echo  "<td>".$vendedor[4]."</td>";
                                    echo  "<td>".$vendedor[5]."</td>";
                                    echo  "<td>".$vendedor[6]."</td>";
                                    echo  "<td>".$vendedor[7]."</td>";
                                    echo  "<td>".$vendedor[8]."</td>";

                                echo "</tr>";
                            }        
                        }  

                    
                    ?>
                </table>
            </div>
            
            <div>
                <p>El vendedor con mas venta es:</p>
                <p>
                    <?php if ($_SESSION['iniciar']>0){
                     echo "<p>".$_SESSION['masVentas']."</p>";
                    }
                    ?>
                </p>
            </div>

            <div class="top_gap2">
                <a href="cerrarSesion.php" class="c_blanco boton boton--secundario">Salir</a>
            </div>
        </main>  
    </div>

    <footer class="footer">
        <div class="contenedor">
            <div class="barra">
                <a class="logo" href="index.html">
                    <h1 class="logo__nombre centrar-texto no-margin">Tienda<span class = "logo__bold">Gamer</span></h1>
                </a>
            
                <nav class="navegacion">
                    <a href="#" class="navegacion__enlace"><img src="img/twiiter.png" width=32 height=32 alt="Síguenos en Twitter" /></a>
                    <a href="#" class="navegacion__enlace"><img src="img/instagram.png" width=32 height=32 alt="Síguenos en Instragram" /></a>
                    <a href="#" class="navegacion__enlace"><img src="img/facebook.png" width=32 height=32 alt="Síguenos en Facebook" /></a>
                    <a href="#" class="navegacion__enlace"><img src="img//wtsp.png" width=32 height=32 alt="Síguenos en watsp" /></a>
                </nav>
            
               
                   
            </div>
        </div>
    </footer>

</body>
</html>