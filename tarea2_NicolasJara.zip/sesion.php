<?php

class Persona {
	private $nombre;
	private $apellido;

    function __construct($nombre,$apellido){
		$this->nombre =$nombre;
		$this->apellido =$apellido;
	}

    function nombrecompleto(){
		return $this->nombre . "" . $this->apellido;
	}

}
$n=$_REQUEST['nom'];
$a=$_REQUEST['ape'];
$cod=$_REQUEST['cod'];
$mnc=$_REQUEST['mnc'];
$fnt=$_REQUEST['fnt'];


session_start();


$_SESSION['error1'] = "";
$_SESSION['error2'] = "";
$_SESSION['error3'] = "";
$_SESSION['error4'] = "";
$_SESSION['masVentas'] = "";


if ($_SESSION['iniciar'] === 0){
    $_SESSION['vendedor'] = [];
}
$_SESSION['iniciar'] = $_SESSION['iniciar'] + 1;    

$persona = new Persona($n,$a);

function validar_user($nombre){
   $permitidos = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
   for ($i=0; $i<strlen($nombre); $i++){
      if (strpos($permitidos, substr($nombre,$i,1))===false){
         return false;
      }
   }
}

if (validar_user($persona->nombrecompleto())===false || ($n === "" || $a === "")  ){
    $_SESSION['error1'] = "Debe escribir un nombre valido";
}else{
    $_SESSION['error1'] = "";
}

function validar_numero($numero){
    $permitidos = "1234567890";
    for ($i=0; $i<strlen($numero); $i++){
       if (strpos($permitidos, substr($numero,$i,1))===false){
          return false;
       }
    }
 }

if (validar_numero($cod)===false || ($cod == "") || $cod <0 ){
    $_SESSION['error2'] = "Debe escribir un número valido";
}else{
    $_SESSION['error2'] = "";
}

if (validar_numero($mnc)===false || ($mnc == "") || $mnc <0 ){
    $_SESSION['error3'] = "Debe escribir un número valido";
}else{
    $_SESSION['error3'] = "";
}

if (validar_numero($fnt)===false || ($fnt == "") || $fnt <0 ){
    $_SESSION['error4'] = "Debe escribir un número valido";
}else{
    $_SESSION['error4'] = "";
}




if (strlen($_SESSION['error1'])>0 || strlen($_SESSION['error2'])>0 || strlen($_SESSION['error3'])>0 || strlen($_SESSION['error4'])>0) {
    header("Location: ventas.php");
}else{
    $comision_cod = $cod*34500*0.06;
    $comision_mnc = $mnc*8800*0.04;
    $comision_fnt = $fnt*58200*0.09;
    $comision_total = $comision_cod + $comision_mnc + $comision_fnt;
    array_push($_SESSION['vendedor'],[$n." ".$a,$cod,$mnc,$fnt,$cod+$mnc+$fnt,$comision_cod,$comision_mnc,$comision_fnt,$comision_total]); 
    
    $_SESSION['masVentas'] = $_SESSION['vendedor'][0][0];
    $maxValue = $_SESSION['vendedor'][0][8];
    foreach($_SESSION['vendedor'] as &$vendedor){
        if ($vendedor[8]>$maxValue){
            $_SESSION['masVentas'] = $vendedor[0];
        }
        echo  "<td>".$vendedor[0]."</td>";
    }   
    
    header("Location: ventas.php");
}


       


?>
